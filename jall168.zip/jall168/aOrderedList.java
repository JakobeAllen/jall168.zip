import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

/**
 * Represents a list of cars maintained in ascending order based on make and year.
 * CSC 1351 Programming Project No. 1
 * Section 002
 * 
 * @author Jakobe Allen
 * @since 3/17/24
 */
class aOrderedList implements Iterable<Car> {
    private List<Car> oList;

    /**
     * Constructs an empty ordered list of cars.
     * CSC 1351 Programming Project No. 1
     * Section 002
     * 
     * @author Jakobe Allen
     * @since 3/17/24
     */
    public aOrderedList() {
        oList = new ArrayList<>();
    }

    /**
     * Adds a new car to the ordered list and sorts it based on make and year.
     * CSC 1351 Programming Project No. 1
     * Section 002
     * 
     * @author Jakobe Allen
     * @since 3/17/24
     */
    public void add(Car newCar) {
        oList.add(newCar);
        Collections.sort(oList);
    }

    /**
     * Returns the number of cars in the ordered list.
     * CSC 1351 Programming Project No. 1
     * Section 002
     * 
     * @author Jakobe Allen
     * @since 3/17/24
     */
    public int size() {
        return oList.size();
    }

    /**
     * Returns the car at the index in the ordered list.
     * CSC 1351 Programming Project No. 1
     * Section 002
     * 
     * @author Jakobe Allen
     * @since 3/17/24
     */
    public Car get(int index) {
        return oList.get(index);
    }

    /**
     * Checks if the ordered list is empty.
     * CSC 1351 Programming Project No. 1
     * Section 002
     * 
     * @author Jakobe Allen
     * @since 3/17/24
     */
    public boolean isEmpty() {
        return oList.isEmpty();
    }

    /**
     * Removes the specified car from the ordered list.
     * CSC 1351 Programming Project No. 1
     * Section 002
     * 
     * @author Jakobe Allen
     * @since 3/17/24
     */
    public void remove(Car car) {
        oList.removeIf(c -> c.getMake().equals(car.getMake()) && c.getYear() == car.getYear());
    }

    /**
     * Returns an iterator over the cars in the ordered list.
     * CSC 1351 Programming Project No. 1
     * Section 002
     * 
     * @author Jakobe Allen
     * @since 3/17/24
     */
    @Override
    public Iterator<Car> iterator() {
        return oList.iterator();
    }
}