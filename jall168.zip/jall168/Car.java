import java.util.Arrays;

/**
 * Car class represents a car with make, year, and price.
 * CSC 1351 Programming Project No. 1
 * Section 002
 * 
 * @author Jakobe Allen
 * @since 3/17/24
 */
class Car implements Comparable<Car> {
    private String make;
    private int year;
    private int price;

    /**
     * Car constructor sets the make, year, and price of the car.
     * CSC 1351 Programming Project No. 1
     * Section 002
     * 
     * @author Jakobe Allen
     * @since 3/17/24
     */
    public Car(String make, int year, int price) {
        this.make = make;
        this.year = year;
        this.price = price;
    }

    /**
     * getMake method returns the make of the car.
     * CSC 1351 Programming Project No. 1
     * Section 002
     * 
     * @author Jakobe Allen
     * @since 3/17/24
     */
    public String getMake() {
        return make;
    }

    /**
     * getYear method returns the year of the car.
     * CSC 1351 Programming Project No. 1
     * Section 002
     * 
     * @author Jakobe Allen
     * @since 3/17/24
     */
    public int getYear() {
        return year;
    }

    /**
     * getPrice method returns the price of the car.
     * CSC 1351 Programming Project No. 1
     * Section 002
     * 
     * @author Jakobe Allen
     * @since 3/17/24
     */
    public int getPrice() {
        return price;
    }

    /**
     * compareTo method compares two cars based on their make and year.
     * CSC 1351 Programming Project No. 1
     * Section 002
     * 
     * @author Jakobe Allen
     * @since 3/17/24
     */
    @Override
    public int compareTo(Car car2) {
        int cmp = this.make.compareTo(car2.make);
        return cmp != 0 ? cmp : Integer.compare(this.year, car2.year);
    }

    /**
     * toString method returns a string representation of the car.
     * CSC 1351 Programming Project No. 1
     * Section 002
     * 
     * @author Jakobe Allen
     * @since 3/17/24
     */
    @Override
    public String toString() {
        return "Make: " + make + ", Year: " + year + ", Price: " + price;
    }
}