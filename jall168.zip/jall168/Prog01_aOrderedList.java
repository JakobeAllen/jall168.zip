import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Arrays;

/**
 * Prog01_aOrderedList is the main program that manages a list of cars. It reads car data from an input file, 
 * performs operations on the list of cars, and outputs the updated list to an output file.
 * CSC 1351 Programming Project No. 1
 * Section 002
 *
 * @author Jakobe Allen
 * @since 3/17/24
 */
public class Prog01_aOrderedList {
    
    /**
     * The main method is the entry point of the program. It reads input from a file, performs operations 
     * on the car list, and outputs the result to a file.
     * CSC 1351 Programming Project No. 1
     * Section 002
     *
     * @author Jakobe Allen
     * @since 3/17/24
     */
    public static void main(String[] args) {
        aOrderedList orderedList = new aOrderedList();

        try (Scanner scanner = getInputFile("Enter input filename: ")) {
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                if (line.startsWith("A")) {
                    String[] parts = line.split(",");
                    if (parts.length == 4) {
                        String make = parts[1];
                        int year = Integer.parseInt(parts[2]);
                        int price = Integer.parseInt(parts[3]);
                        Car car = new Car(make, year, price);
                        orderedList.add(car);
                    }
                } else if (line.startsWith("D")) {
                    String[] parts = line.split(",");
                    if (parts.length == 3) {
                        String make = parts[1];
                        int year = Integer.parseInt(parts[2]);
                        Car car = new Car(make, year, 0); 
                        orderedList.remove(car);
                    }
                }
            }

            /**
             * Output the content of the list
             * CSC 1351 Programming Project No. 1
             * Section 002
             *
             * @author Jakobe Allen
             * @since 3/17/24
             */ 
            PrintWriter writer = getOutputFile("Enter output filename: ");
            writer.println("Number of cars: " + orderedList.size());
            for (Car car : orderedList) {
                writer.println("Make: " + car.getMake());
                writer.println("Year: " + car.getYear());
                writer.println("Price: $" + car.getPrice());
                writer.println();
            }
            writer.close();
        } catch (FileNotFoundException e) {
            System.out.println("File not found.");
        }
    }

    /**
     * getInputFile method prompts the user for an input file name, checks if the file exists, 
     * and returns a Scanner object to read from the file.
     * CSC 1351 Programming Project No. 1
     * Section 002
     *
     * @author Jakobe Allen
     * @since 3/17/24
     */          
    public static Scanner getInputFile(String userPrompt) throws FileNotFoundException {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.print(userPrompt);
            String fileName = scanner.nextLine();
            File file = new File(fileName);
            if (file.exists() && file.isFile()) {
                return new Scanner(file);
            } else {
                System.out.println("File specified <" + fileName + "> does not exist. Would you like to continue? <Y/N>");
                String choice = scanner.nextLine().toUpperCase();
                if (!choice.equals("Y")) {
                    throw new FileNotFoundException();
                }
            }
        }
    }

    /**
     * getOutputFile method prompts the user for an output file name, creates a PrintWriter object to write 
     * to the file, and handles FileNotFoundException.
     * CSC 1351 Programming Project No. 1
     * Section 002
     *
     * @author Jakobe Allen
     * @since 3/17/24
     */          
    public static PrintWriter getOutputFile(String userPrompt) throws FileNotFoundException {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.print(userPrompt);
            String fileName = scanner.nextLine();
            File file = new File(fileName);
            try {
                return new PrintWriter(file);
            } catch (FileNotFoundException e) {
                System.out.println("Invalid filename or path. Please try again.");
            }
        }
    }
}